<?php

use App\Http\Controllers\User\SolicitudController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', fn () => 'ERROR');

Route::get('/verificar-correo', [SolicitudController::class, 'verificarCorreo']);
Route::get('/correo-verificado', [SolicitudController::class, 'correoVerificado']);
