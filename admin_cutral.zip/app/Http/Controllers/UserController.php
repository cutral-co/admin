<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Models\App;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB, Http};

use App\Models\User;

class UserController extends Controller
{

}
